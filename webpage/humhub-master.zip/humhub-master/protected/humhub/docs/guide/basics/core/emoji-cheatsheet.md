# Emoji Cheatsheet

The following is a cheatsheet for the Emoji feature of HumHub

| Emoji Code | Emoji Rendered|
| --- | --- |
| `:smile:` | :smile: |
| `:frown:` | :frown: (Doesn't render on GitHub because it is `frowning`) |
| `:tongue:`| :tongue: |

> Will add more later as it will take some time to finish...
