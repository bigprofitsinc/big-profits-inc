Theme - Module Integration
==========================

TBD

> Info: If your theme directory resides outside the `themes` directory of your HumHub project while developement, you'll have to edit the `@HUMHUB` path variable within the `build.less` file to point to the `static/less` folder of your HumHub project directory.


