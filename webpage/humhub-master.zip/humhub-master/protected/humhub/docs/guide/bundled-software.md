Bundled Software / Libaries
===========================

> This list may incomplete!

* Yii Framework (Core Framework) http://www.yiiframework.com/ (protected/vendors/yii/LICENSE)
* Zend Framework http://framework.zend.com/ (protected/vendors/Zend/LICENSE.txt, protected/vendors/Zend2/LICENSE.txt)
* Code Igniter (Security Functions) http://ellislab.com/codeigniter
* Yii Extensions (See /protected/extensions/)
* Yii-Mail - http://www.yiiframework.com/extension/mail/
* SwiftMailer - http://swiftmailer.org
* jQuery - http://jquery.com
* jQuery Cookie Plugin - https://github.com/carhartl/jquery-cookie
* jQuery Knob - http://anthonyterrien.com/knob/
* Twitter Bootstrap - http://getbootstrap.com/
* Lightbox for Bootstrap 3 - https://github.com/ashleydw/lightbox
* Modernizr - http://modernizr.com/
* HTML5 Shiv - https://github.com/aFarkas/html5shiv
* Wysihtml5 - https://github.com/xing/wysihtml5
* Bootstrap-wysihtml5 - http://jhollingworth.github.io/bootstrap-wysihtml5/
* Autosize - http://www.jacklmoore.com/autosize
* Highlight - http://johannburkard.de/blog/programming/javascript/highlight-javascript-text-higlighting-jquery-plugin.html
* Timeago - http://timeago.yarp.com/
* NiceScroll - https://github.com/inuyaksa/jquery.nicescroll
* Controller-Events - http://www.yiiframework.com/extension/controller-events/
* HTML5 Placeholder jQuery Plugin - https://github.com/mathiasbynens/jquery-placeholder
* animate.css by Daniel Eden - http://daneden.me/animate
* jplayer - http://jplayer.org/
* At.js - http://ichord.github.io/At.js/
* Cebe Markdown - https://github.com/cebe/markdown
* Highlight.js - https://highlightjs.org/
* Bootstrap Markdown - http://www.codingdrama.com/bootstrap-markdown/
* JShrink - https://github.com/tedious/JShrink
* CSSCompressor - http://www.yiiframework.com/extension/minifyclientscript/
* Sample avatars designed by http://www.freepik.com
* twemoji - https://github.com/twitter/twemoji