# Licence

Find more about HumHub Licence here:
https://www.humhub.org/licences


