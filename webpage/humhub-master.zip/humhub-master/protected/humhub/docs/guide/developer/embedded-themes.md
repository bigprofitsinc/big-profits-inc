Embedded themes
=================

(TBD)