<?php
return array (
  '<strong>Login</strong> required' => '<strong>Indentification</strong> requise',
  'An internal server error occurred.' => 'Une erreur interne au serveur est survenue.',
  'Guest mode not active, please login first.' => 'Mode invité inactif, merci de vous identifier d\'abord.',
  'Login required for this section.' => 'Identification nécessaire pour accéder à cette section.',
  'You are not allowed to perform this action.' => 'Vous n\'êtes pas autorisé à effectuer cette action.',
  'You are not permitted to access this section.' => 'Vous n\'avez pas le droit d\'accéder à cette section.',
  'You need admin permissions to access this section.' => 'Vous avez besoin des droits administrateur pour accéder à cette section.',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => 'Votre compte n\'a pas encore été approuvé, veuillez réessayer ultérieurement ou contactez un administrateur du site.',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => 'Votre compte est inactif, veuillez vous connecter avec un autre compte actif ou contactez un administrateur du site.',
);
