<?php
return array (
  '<strong>Login</strong> required' => '<strong>Prijava</strong> potrebna',
  'An internal server error occurred.' => 'Došlo je do unutarnje pogreške poslužitelja.',
  'Guest mode not active, please login first.' => 'Način rada Gosta nije aktivan, prvo se prijavite.',
  'Login required for this section.' => 'Prijava potrebna za ovaj odjeljak.',
  'You are not allowed to perform this action.' => 'Nije vam dozvoljena ova akcija.',
  'You are not permitted to access this section.' => 'Nije vam dopušteno pristupiti ovom odjeljku.',
  'You need admin permissions to access this section.' => 'Trebate administratorske ovlasti za pristup ovom odjeljku.',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => 'Vaš korisnički račun još nije odobren, pokušajte ponovo kasnije ili se obratite mrežnom administratoru.',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => 'Vaš korisnički račun nije aktivan, prijavite se aktivnim računom ili se obratite mrežnom administratoru.',
);
