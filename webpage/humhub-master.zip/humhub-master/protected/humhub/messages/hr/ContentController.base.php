<?php
return array (
  'Invalid content id given!' => 'Navedeni ID sadržaj nije valjan!',
);
