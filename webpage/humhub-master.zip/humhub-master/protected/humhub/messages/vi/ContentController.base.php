<?php
return array (
  'Invalid content id given!' => 'ID nội dung không hợp lệ!',
);
