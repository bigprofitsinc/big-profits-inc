<?php
return array (
  'Invalid content id given!' => 'Content ID is ongeldig!',
);
