<?php
return array (
  '<strong>Login</strong> required' => '<strong>Inloggning</strong> krävs',
  'An internal server error occurred.' => 'Ett internt serverfel inträffade.',
  'Guest mode not active, please login first.' => 'Gästläge är inte aktivt, vänligen logga in först.',
  'Login required for this section.' => '',
  'You are not allowed to perform this action.' => 'Du har inte tillåtelse att utföra denna åtgärd.',
  'You are not permitted to access this section.' => '',
  'You need admin permissions to access this section.' => '',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => '',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => '',
);
