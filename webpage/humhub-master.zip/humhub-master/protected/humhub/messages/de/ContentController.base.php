<?php
return array (
  'Invalid content id given!' => 'Ungültige Inhalts-ID angegeben!',
);
