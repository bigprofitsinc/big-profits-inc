<?php
return array (
  'Invalid content id given!' => 'Il Content id fornito non è valido!',
);
