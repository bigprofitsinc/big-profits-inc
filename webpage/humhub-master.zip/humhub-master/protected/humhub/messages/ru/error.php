<?php
return array (
  '<strong>Login</strong> required' => 'Необходима <strong>авторизация</strong>',
  'An internal server error occurred.' => 'Произошла внутренняя ошибка сервера.',
  'Guest mode not active, please login first.' => 'Гостевой режим не активен, пожалуйста авторизуйтесь.',
  'Login required for this section.' => 'Для доступа к этому разделу требуется авторизация.',
  'You are not allowed to perform this action.' => 'Вы не можете выполнить это действие.',
  'You are not permitted to access this section.' => 'Нет доступа к этому разделу.',
  'You need admin permissions to access this section.' => 'Требуются права администратора для доступа к этому разделу.',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => '',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => 'Ваша учетная запись не активна, пожалуйста войдите используя активную учетную запись или свяжитесь с администратором сети.',
);
