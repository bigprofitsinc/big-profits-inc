<?php
return array (
  'Invalid content id given!' => 'ID de conteniu invalida!',
);
