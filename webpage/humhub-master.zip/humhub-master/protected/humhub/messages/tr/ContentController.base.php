<?php
return array (
  'Invalid content id given!' => 'Geçersiz içerik kimliği!',
);
