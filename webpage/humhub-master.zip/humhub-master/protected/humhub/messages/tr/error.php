<?php
return array (
  '<strong>Login</strong> required' => 'Oturum açınız',
  'An internal server error occurred.' => 'Sunucu hatası oluştu.',
  'Guest mode not active, please login first.' => 'Misafir modu aktif değil, lütfen önce giriş yapın.',
  'Login required for this section.' => 'Bu bölüm için giriş gerekli.',
  'You are not allowed to perform this action.' => 'Bu eylemi gerçekleştirmek için izin gereklidir.',
  'You are not permitted to access this section.' => 'Bu bölüme erişme izniniz yok.',
  'You need admin permissions to access this section.' => 'Bu bölüme erişmek için yönetici izinlerine ihtiyacınız var.',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => 'Kullanıcı hesabınız henüz onaylanmadı. Lütfen daha sonra tekrar deneyin veya bir ağ yöneticisine başvurun.',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => 'Kullanıcı hesabınız etkin değil, lütfen aktif bir hesapla giriş yapın veya bir ağ yöneticisine başvurun.',
);
