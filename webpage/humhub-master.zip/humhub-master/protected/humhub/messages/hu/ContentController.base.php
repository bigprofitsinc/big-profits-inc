<?php
return array (
  'Invalid content id given!' => 'A megadott tartalomazonosító érvénytelen!',
);
