<?php
return array (
  '<strong>Login</strong> required' => '<strong>Bejelentkezés</strong> szükséges',
  'An internal server error occurred.' => 'Belső szerverhiba történt.',
  'Guest mode not active, please login first.' => 'A vendég mód nem engedélyezett, előbb lépj be.',
  'Login required for this section.' => 'Bejelentkezés szükséges ehhez a szekcióhoz.',
  'You are not allowed to perform this action.' => 'Nem engedélyezett számodra ez a művelet.',
  'You are not permitted to access this section.' => 'Nincs hozzáférésed a szekcióhoz.',
  'You need admin permissions to access this section.' => 'Engedélyre van szükséged, hogy ehhez a szekcióhoz hozzáférhess.',
  'Your user account has not been approved yet, please try again later or contact a network administrator.' => 'A felhasználói fiókod még nincs jóváhagyva. Kérjük, próbálkozz később vagy lépj kapcsolatba egy hálózati adminisztrátorral.',
  'Your user account is inactive, please login with an active account or contact a network administrator.' => 'A felhasználói fiókod inaktív. Kérjük, jelentkezz be egy aktív fiókkal vagy lépj kapcsolatba egy hálózati adminisztrátorral.',
);
