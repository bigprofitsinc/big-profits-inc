<?php
return array (
  'Invalid content id given!' => '無効なコンテンツIDが指定されました!',
);
