<?php
return array (
  'Invalid content id given!' => 'Informado ID de conteúdo inválido!',
);
