<?php
return array (
  'Invalid content id given!' => 'L\'identificador de contingut no és vàlid!',
);
