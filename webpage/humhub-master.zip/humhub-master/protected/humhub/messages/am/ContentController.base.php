<?php
return array (
  'Invalid content id given!' => 'የሰጡት የማያገለግል የይዘት መለያ ነው!',
);
