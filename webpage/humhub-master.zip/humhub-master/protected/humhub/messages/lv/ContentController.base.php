<?php
return array (
  'Invalid content id given!' => 'Norādīts kļūdains satura id!',
);
