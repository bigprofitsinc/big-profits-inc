<?php
return array (
  'Invalid content id given!' => '¡Se ha introducido un id de contenido no válido!',
);
