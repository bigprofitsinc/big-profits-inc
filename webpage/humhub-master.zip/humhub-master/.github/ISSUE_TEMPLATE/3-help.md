---
name: "⁉️ Need help with HumHub?"
about: Please post your problem in our community.

---

If you have a question or problem about HumHub that is not a bug report or feature
request, please post it in https://community.humhub.com!

Questions posted to this repository will be closed.
