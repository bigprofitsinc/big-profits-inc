---
name: "\U0001F680 Feature request"
about: Suggest an idea for this project

---

<!--
Thank you for suggesting an idea to make HumHub better.

Please fill in as much of the template below as you can.
-->


### Is your feature request related to a problem? Please describe.

### Describe the solution you'd like

### Describe alternatives you've considered

